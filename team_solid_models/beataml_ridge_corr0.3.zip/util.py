import pandas, numpy, os, joblib
from itertools import product
from sklearn.linear_model import LinearRegression


def Rnaseq_process(rnaseq_dir):
    rnaseq_path = os.path.join(rnaseq_dir, "rnaseq.csv")
    rnaseq = pandas.read_csv(rnaseq_path)
    rnaseq_T = rnaseq.T.copy()
    gene_list = rnaseq.Gene.copy()
    rnaseq_T = rnaseq_T.drop("Gene").drop("Symbol")
    rnaseq_T.columns = gene_list
    rnaseq_T = rnaseq_T.astype("float32")
    return rnaseq_T

def Dnaseq_process(dnaseq_dir):
    dnaseq_path = os.path.join(dnaseq_dir, "dnaseq.csv")
    dnaseq = pandas.read_csv(dnaseq_path)
    row_names = dnaseq.lab_id.unique()
    col_names = dnaseq.Hugo_Symbol.unique()
    dna_mat = pandas.DataFrame(numpy.zeros((len(row_names), len(col_names))))
    dna_mat = dna_mat.astype("int")
    dna_mat.columns = col_names
    dna_mat.index = row_names
    for i in range(dnaseq.shape[0]):
        x = dnaseq.lab_id[i]
        y = dnaseq.Hugo_Symbol[i]
        dna_mat.loc[x, y] = 1
    return dna_mat

def RunPrediction(model_dir, input_dir, output_dir):
    print("start prediction")
    rnaseq = Rnaseq_process(input_dir)
    gene_dict = joblib.load(os.path.join(model_dir, "selected_genes.pkl"))
    inhibitors = joblib.load(os.path.join(model_dir, "inhibitors.pkl"))
    specimens = rnaseq.index
    aucs = pandas.DataFrame(product(inhibitors, specimens),columns=['inhibitor', 'lab_id'])
    aucs["auc"] = 0
    for i in aucs.index:
        lab_id = aucs.lab_id[i]
        inhibitor = aucs.inhibitor[i]
        model = joblib.load(os.path.join(model_dir, inhibitor+".pkl"))
        aucs.auc[i] = model.predict(numpy.array(rnaseq[gene_dict[inhibitor]].loc[lab_id]).reshape(1, -1))[0]
    aucs.to_csv(os.path.join(output_dir, 'predictions.csv'), index=False)

def RunPredNoSelection(model_dir, input_dir, output_dir):
    dnaseq = Dnaseq_process(input_dir)
    inhibitors = joblib.load(os.path.join(model_dir, "inhibitors.pkl"))
    selected_dna = joblib.load(os.path.join(model_dir, "selected_DNA.pkl"))
    specimens = dnaseq.index
    aucs = pandas.DataFrame(product(inhibitors, specimens), columns=['inhibitor', 'lab_id'])
    aucs["auc"] = 0
    for i in aucs.index:
        lab_id = aucs.lab_id[i]
        inhibitor = aucs.inhibitor[i]
        model = joblib.load(os.path.join(model_dir, inhibitor+".pkl"))
        print(len(dnaseq.columns))
        print(len(selected_dna))
        print(dnaseq.columns in list(selected_dna))
        aucs.auc[i] = model.predict(numpy.array(dnaseq[selected_dna].loc[lab_id]).reshape(1, -1))[0]
    aucs.to_csv(os.path.join(output_dir, 'predictions.csv'), index=False)