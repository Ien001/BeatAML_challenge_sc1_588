import util
import os

if __name__ == "__main__":
    #util.RunPredNoSelection(os.getcwd()+'\model', os.getcwd()+'\input', os.getcwd()+'\output')
    util.RunPrediction('/model', '/input', '/output')